// Ninja to Cat Assignment
$(function() {

    $("p").on("click", function() {
        $(this).find("img").toggle();
    });

});