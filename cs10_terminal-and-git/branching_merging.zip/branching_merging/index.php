<!DOCTYPE html>
<html>
<head lang="en">
    <meta charset="UTF-8">
    <title>Branching and Merging Assignment</title>
    <link rel="stylesheet" type="text/css" href="less/styles.css" />
</head>
<body>

    <div id="wrapper">

        <h1>Coding Dojo Rocks!</h1>

        <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Donec quam felis, ultricies nec, pellentesque eu, pretium quis, sem. Nulla consequat massa quis enim. Donec pede justo, fringilla vel, aliquet nec, vulputate eget, arcu.</p>

        <p><img src="images/dog-on-grass.png" alt="here" width="300" height="200" /><img src="images/pres-fdr-with-dog.png" alt="here" width="300" height="200" /><img src="images/dog-on-carpet.png" alt="here" width="300" height="200" /><img src="images/dog-in-front-of-mountain.png" alt="here" width="300" height="200" /></p>

    </div>

</body>
</html>